import 'package:flutter/material.dart';
void main()=>runApp(const CafeGhablApp());
class CafeGhablApp extends StatelessWidget{
 const CafeGhablApp({super.key});
 @override Widget build(BuildContext context)=>MaterialApp(
  title:'کافه‌قبل',debugShowCheckedModeBanner:false,
  theme:ThemeData(useMaterial3:true,colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xFF80543C))),
  home:const Directionality(textDirection:TextDirection.rtl,child:CafeHome()));
}
class Item{final String name,desc;final int price;const Item(this.name,this.desc,this.price);}
class Cafe{final String name,city,desc;final List<Item> items;const Cafe(this.name,this.city,this.desc,this.items);}
const cafes=[
 Cafe('کافه نمونه یک','تهران، مرکز شهر','قهوه تخصصی',[
  Item('آمریکانو','قهوه اسپرسو با آب داغ',95000),Item('لاته','اسپرسو با شیر',125000),Item('کاپوچینو','اسپرسو و کف شیر',120000)]),
 Cafe('کافه نمونه دو','شیراز، معالی‌آباد','قهوه و میان‌وعده',[
  Item('اسپرسو','یک شات اسپرسو',80000),Item('موکا','قهوه و شکلات',135000),Item('چای','چای تازه‌دم',55000)])];
class CafeHome extends StatefulWidget{const CafeHome({super.key});@override State<CafeHome> createState()=>_CafeHomeState();}
class _CafeHomeState extends State<CafeHome>{
 final Map<String,int> cart={};String time='۱۵ دقیقه دیگر';
 int get total{int sum=0;for(final c in cafes){for(final i in c.items){sum+=i.price*(cart[i.name]??0);}}return sum;}
 String toman(int n)=>'${n} تومان';
 void add(Item i)=>setState(()=>cart[i.name]=(cart[i.name]??0)+1);
 void showCart()=>showModalBottomSheet(context:context,isScrollControlled:true,builder:(ctx)=>Directionality(textDirection:TextDirection.rtl,child:Padding(padding:const EdgeInsets.all(18),child:SafeArea(child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.stretch,children:[
 const Text('سبد سفارش',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),const SizedBox(height:8),
 if(cart.isEmpty)const Text('هنوز محصولی انتخاب نکرده‌اید.'),
 ...cart.entries.map((e)=>ListTile(title:Text(e.key),subtitle:Text('تعداد: ${e.value}'),trailing:IconButton(icon:const Icon(Icons.remove_circle_outline),onPressed:()=>setState(()=>e.value<=1?cart.remove(e.key):cart[e.key]=e.value-1)))),
 const Divider(),Text('جمع کل: ${toman(total)}',style:const TextStyle(fontWeight:FontWeight.bold)),
 DropdownButtonFormField<String>(value:time,decoration:const InputDecoration(labelText:'زمان مراجعه'),items:const ['۱۵ دقیقه دیگر','۳۰ دقیقه دیگر','۴۵ دقیقه دیگر','یک ساعت دیگر'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),onChanged:(v)=>setState(()=>time=v??time)),
 const SizedBox(height:12),FilledButton(onPressed:cart.isEmpty?null:(){Navigator.pop(ctx);showDialog(context:context,builder:(d)=>AlertDialog(title:const Text('نسخه آزمایشی'),content:const Text('سفارش و پرداخت واقعی هنوز به سرور متصل نشده‌اند.'),actions:[TextButton(onPressed:()=>Navigator.pop(d),child:const Text('متوجه شدم'))]));},child:const Text('ادامه به پرداخت'))
 ])))));
 @override Widget build(BuildContext context)=>Scaffold(
 appBar:AppBar(title:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('کافه‌قبل',style:TextStyle(fontWeight:FontWeight.bold)),Text('قبل از رسیدن سفارش بده',style:TextStyle(fontSize:12))]),actions:[IconButton(onPressed:showCart,icon:const Icon(Icons.shopping_bag_outlined))]),
 body:ListView(padding:const EdgeInsets.all(16),children:[
 Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:const Color(0xFF80543C),borderRadius:BorderRadius.circular(18)),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('قهوه‌ات منتظرته ☕',style:TextStyle(color:Colors.white,fontSize:23,fontWeight:FontWeight.bold)),SizedBox(height:8),Text('کافه را انتخاب کن و بدون معطلی لذت ببر.',style:TextStyle(color:Colors.white))]),
 const SizedBox(height:18),const Text('کافه‌های پیشنهادی',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
 ...cafes.map((c)=>Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
 Text(c.name,style:const TextStyle(fontSize:17,fontWeight:FontWeight.bold)),Text(c.city),Text(c.desc),const Divider(),
 ...c.items.map((i)=>ListTile(contentPadding:EdgeInsets.zero,title:Text(i.name),subtitle:Text('${i.desc}\\n${toman(i.price)}'),isThreeLine:true,trailing:IconButton(onPressed:()=>add(i),icon:const Icon(Icons.add_circle,size:30))))
 ])))),
 const Text('توجه: نام کافه‌ها و قیمت‌ها نمونه هستند. نسخه فعلی نمایشی است.',style:TextStyle(color:Colors.grey))
 ]),
 floatingActionButton:FloatingActionButton.extended(onPressed:showCart,icon:const Icon(Icons.shopping_bag),label:Text('سبد (${cart.values.fold<int>(0,(a,b)=>a+b)})')));
}
